export enum LoginTypes{
    LOGIN ='[Login] user login',
    LOGIN_SUCCESS = '[Login] login succcess',
    LOGIN_ERROR ='[Login] login error '
} 